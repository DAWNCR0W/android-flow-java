package com.donghyeokseo.flow.api.school;

public class SchoolException extends Exception {

    public SchoolException() {}

    SchoolException(String message) {
        super(message);
    }
}