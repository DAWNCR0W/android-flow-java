package com.donghyeokseo.flow.delegate;

/**
 * @author dawncrow
 */
public interface OnParseMeal {
    void onParseMeal();
}
